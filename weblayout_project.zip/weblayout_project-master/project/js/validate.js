const validation = new JustValidate('.form');

validation
  .addField('.input-name',[
    {
      rule: 'minLength',
      value: 2,
      errorMessage: 'Минимум 2 символа'
    },
    {
      rule: 'maxLength',
      value: 30,
      errorMessage: 'Максимум 30 символов'
    },
    {
      rule: 'required',
      errorMessage: 'Ошибка',
    },

    {
      rule: 'customRegexp',
      value: /[a-я]/gi,
      errorMessage: 'Недопустимый символ',
    }
  ])

  .addField('.input-mail',[
    {
      rule: 'minLength',
      value: 3,
      errorMessage: 'Минимум 3 символа'
    },
    {
      rule: 'maxLength',
      value: 35,
      errorMessage: 'Максимум 35 символов'
    },
    {
      rule: 'required',
      value: true,
      errorMessage: 'Ошибка'
    },
    {
      rule: 'email',
      errorMessage: 'Не корректный E-mail'
    }
  ])

  .addField('.form__textaria', [
    {
      rule: 'minLength',
      value: 6,
      errorMessage: 'Введите минимум 6 символов',
    },
    {
      rule: 'required',
      value: true,
      errorMessage: 'Введите минимум 6 символов'
    }
  ])

  .addField('.form__check',[
    {
      rule: 'required',
      errorMessage: 'Необходимо подтверждение'
    },
  ]).onSuccess((event) => {
    console.log('INVALID', event);

    let formData = new FormData(event.target);

    console.log(...formData);

    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          console.log('Отправлено');
        }
      }
    }

  xhr.open('POST', 'mail.php', true);
  xhr.send(formData);

  event.target.reset();
});



