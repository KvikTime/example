(()=> {
    function setSearch(params) {
        const openBtn = document.querySelector(`.${params.openBtnClass}`);
        const openReg = document.querySelector(`.${params.openRegClass}`);
        const search = document.querySelector(`.${params.regClass}`);
        const closeBtn = search.querySelector(`.${params.closeBtnClass}`);

        search.addEventListener("animationend", function (evt) {
          if (this._isOpened) {
            this.classList.remove(params.activeClass);
            this.classList.remove(params.hiddenClass);
            this._isOpened = false;
          } else {
            this._isOpened = true;
          }
        });

        search.addEventListener('click', function(evt) {
          evt._isSearch = true;
        });
        openBtn.addEventListener("click", function (evt) {
          this.disabled = true;
          if (
            !search.classList.contains(params.activeClass) &&
            !search.classList.contains(params.hiddenClass)
          ) {
            search.classList.add(params.activeClass);
          }
        });
        closeBtn.addEventListener('click', function () {
          openBtn.disabled = false;
          search.classList.add(params.hiddenClass);
        });
        document.body.addEventListener('click', function (evt) {
          if (!evt._isSearch && search._isOpened) {
            openBtn.disabled = false;
            search.classList.add(params.hiddenClass);
          }
        });

        search.addEventListener('click', function(evt) {
          evt._isSearch = true;
        });
        openReg.addEventListener("click", function (evt) {
          this.disabled = true;
          if (
            !search.classList.contains(params.activeClass) &&
            !search.classList.contains(params.hiddenClass)
          ) {
            search.classList.add(params.activeClass);
          }
        });
        closeBtn.addEventListener('click', function () {
          openReg.disabled = false;
          search.classList.add(params.hiddenClass);
        });
        document.body.addEventListener('click', function (evt) {
          if (!evt._isSearch && search._isOpened) {
            openReg.disabled = false;
            search.classList.add(params.hiddenClass);
          }
        });

        document.body.addEventListener('click', function (evt) {
          if (!evt._isSearch && search._isOpened) {
            openReg.disabled = false;
            search.classList.add(params.hiddenClass);
          }
        });
      }

      setSearch({
        openRegClass: "open-bottom", // класс кнопки открытия
        openBtnClass: "open-top", // класс кнопки открытия
        closeBtnClass: "register__close", // класс кнопки закрытия
        regClass: "header__register", // класс формы поиска
        activeClass: "reg-visible", // класс открытого состояния
        hiddenClass: "reg-close" // класс закрывающегося состояния (удаляется сразу после закрытия)
      });
})();



const btnMore = document.querySelector('.podcasts__button');
const podcastsItem = document.querySelectorAll('.podcasts__item');

btnMore.addEventListener('click', () => {
  podcastsItem.forEach(el => { el.classList.add('podcasts__item--visible') });
  btnMore.closest('.podcasts__more').classList.add('podcasts__more--hidden');
});


let tabsBtn = document.querySelectorAll(".guests__btn");
let tabsItem = document.querySelectorAll(".guests__card");

tabsBtn.forEach(function(element){
  element.addEventListener("click", function(e){
    const path = e.currentTarget.dataset.path;

    tabsBtn.forEach(function(btn){ btn.classList.remove("active")});
    e.currentTarget.classList.add("active");

    tabsItem.forEach(function(element){ element.classList.remove("guests-active")});
    document.querySelector(`[data-target="${path}"]`).classList.add("guests-active");
  })
});



