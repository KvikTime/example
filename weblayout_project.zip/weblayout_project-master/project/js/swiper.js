const swiper = new Swiper('.swiper', {
  loop: true,

  breakpoints: {
    // когда ширина больше >= 320px
    320: {

      slidesPerView: 2,
      spaceBetween: 20,
      loopedSlides: 4,
    },

    375: {
      slidesPerView: 2,
      spaceBetween: 30,
      loopedSlides: 4
    },

  // когда ширина больше >= 770px
    770: {
      slidesPerView: 2,
      spaceBetween: 30,
      loopedSlides: 4
    },

    // когда ширина больше >= 1026px
    1026: {
      slidesPerView: 4,
      spaceBetween: 30,
      loopedSlides: 4
    }
  },


  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
    enabled: true,
  },

});












// const swiper = new Swiper('.swiper', {
//   breakpoints: {
//     // когда ширина окна >= 320px
//     320: {
//       slidesPerView: 2,
//       spaceBetween: 30,
//       loopedSlides: 2,
//       loop: true,
//     },
//   },

//   breakpoints: {
//     // когда ширина окна >= 1140px
//     1366: {
//       slidesPerView: 4,
//       loopedSlides: 4,
//       loopedSlides: 2,
//       loop: true,
//     },
//   },


//   navigation: {
//     nextEl: '.swiper-button-next',
//     prevEl: '.swiper-button-prev',
//   },

// });
